

function agregardatos(codigo, nombre, descripcion, stock, stockcritico, stockreposicion, precioventa, idproveedor){

	cadena = "codigo=" + codigo +
		"&nombre=" + nombre +
		"&descripcion=" + descripcion +
		"&stock=" + stock +
		"&stockcritico=" + stockcritico +
		"&stockreposicion=" + stockreposicion +
		"&precioventa=" + precioventa +
		"&idproveedor=" + idproveedor ;
         
	 $.ajax({
		type:"POST",
		url:"php/agregarDatos.php",
		data:cadena,
		success:function(r){
			if(r==1){

                $('#tabla').load('componentes/tabla.php');
				alertify.success("agregado con exito :)");
				
				
			}else{
				alertify.error("Fallo el servidor :(");
			}
		}

	});
}

function agregafrom(datos){
	
	d=datos.split('||');
	
	
	
	$('#id_Codigo_Editar').val(d[0]);
	$('#id_Nombre_Editar').val(d[1])
	$('#id_Descripción_Editar').val(d[2]);
	$('#id_Stock_Editar').val(d[3]);
	$('#id_Stcok_Critico_Editar').val(d[4]);
	$('#id_Stock_Posición_Editar').val(d[5]);
	$('#id_Precio_Editar').val(d[6]);
	$('#id_ Proveedor_Editar').val(d[7]);


	
	
}


function actualizadatos(){

	codigo = $('#id_Codigo_Editar').val();
	nombre = $('#id_Nombre_Editar').val();
	descripción = $('#id_Descripción_Editar').val();
	stock = $('#id_Stock_Editar').val();
	stockcritico = $('#id_Stcok_Critico_Editar').val();
	stockposición = $('#id_Stock_Posición_Editar').val();
	precio = $('#id_Precio_Editar').val();
	proveedor = $('#id_ Proveedor_Editar').val();
       

	cadena = "codigo=" + codigo +
		"&nombre=" + nombre +
		"&descripcion=" + descripcion +
		"&stock=" + stock +
		"&stockcritico=" + stockcritico +
		"&stockreposicion=" + stockreposicion +
		"&precioventa=" + precioventa +
		"&idproveedor=" + idproveedor;

	 $.ajax({
		type:"POST",
		url:"php/actualizaDatos.php",
		data:cadena,
		success:function(r){
			if(r==1){

				$('#tabla').load('componentes/tabla.php');
				alertify.success("actualizado con exito :)");
				
			}else{
				
				alertify.error("Fallo el servidor :(");
			}
		}

	});


}

function preguntarSi_No(codigo,des){

	alertify.confirm('Eliminar Datos', 'Esta seguro de eliminar este registro'+' (      '+des+ ')    ?', 
		function () { eliminardatos(codigo) },
                 function(){ alertify.error('Cancelado')});
}

function eliminardatos(codigo){

	cadena = "codigo=" + codigo;
    $.ajax({
    	type:"POST",
    	 url:"php/eliminarDatos.php",
    	data:cadena,
    	success:function(r){
    		if(r==1){

                  $('#tabla').load('componentes/tabla.php');
				alertify.success("Eliminado con exito! :)");
    		}else{
    			alertify.error("Fallo el servidor :(");

    		}

    	}

     
    });

    function mostrar(){
    	document.getElementById('contenedor').style.display="none";

    }
    function ocultar(){
    	document.getElementById('contenedor').style.display="block";


    }

}