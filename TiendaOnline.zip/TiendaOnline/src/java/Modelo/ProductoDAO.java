package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;

    //*******Operaciones CRUD***************//    
    public List listar() {
        String sql = "select * from producto";
        List<Producto> lista = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto em = new Producto();
                em.setCodigo(rs.getInt(1));
                em.setNombre(rs.getString(2));
                em.setDescripcion(rs.getString(3));
                em.setPrecio(rs.getInt(4));
                em.setProvedor(rs.getString(5));
                lista.add(em);
            }
        } catch (Exception e) {
        }
        return lista;
    }

    public int agregar(Producto p) {
        String sql = "insert into producto(nombre, descripcion,precio,provedor)values(?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setInt(3, p.getPrecio());
            ps.setString(4, p.getProvedor());
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return r;

    }

    public Producto listarId(int id) {
        Producto pr = new Producto();
        String sql = "select * from producto where codigo=" + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                pr.setCodigo(rs.getInt(1));
                pr.setNombre(rs.getString(2));
                pr.setDescripcion(rs.getString(3));
                pr.setPrecio(rs.getInt(4));
                pr.setProvedor(rs.getString(5));
            }
        } catch (Exception e) {
        }
        return pr;
    }

    public int actualizar(Producto em) {
        String sql = "update producto set nombre=?, descripcion=?, precio=?, provedor=? where codigo=?";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, em.getNombre());
            ps.setString(2, em.getDescripcion());
            ps.setInt(3, em.getPrecio());
            ps.setString(4, em.getProvedor());
            ps.setInt(5, em.getCodigo());
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return r;
    }

    public void delete(int id) {
        String sql = "delete from producto where IdProducto=" + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
}
